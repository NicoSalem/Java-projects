import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Formatter;

// Import any package as required

public class HuffmanSubmit implements Huffman {
//	
	static class Tree_node  {
		
		char data;
		int freq;
		Tree_node right;
		Tree_node left;
		Tree_node prev;
		
		public Tree_node(char data, int freq) {
			this.data = data;
			this.freq = freq;
			
		}
	}

	// Feel free to add more methods and variables as required. 

	static HashMap<Character, Integer> map = new HashMap<Character, Integer>();
	static HashMap<Character, String> encodeMap = new HashMap<Character, String>();
	static HashMap<Character, Integer> decodeMap = new HashMap<Character, Integer>();
	static String binaryRep = "";
	static String binaryPath = "";

	//static BinaryIn bini = new BinaryIn("C:\\Users\\Nico\\Documents\\SEMESTER 3\\CSC 172\\proj2 huffman\\outputFile.enc");
	//static Tree_node start = makeTree();
	static String inputfile = "C:\\Users\\Nico\\Documents\\SEMESTER 3\\CSC 172\\proj2 huffman\\alice30.txt";
	static String outputfile = "C:\\Users\\Nico\\Documents\\SEMESTER 3\\CSC 172\\proj2 huffman\\outputFilesTXT.enc";
	static String freqfile = "C:\\Users\\Nico\\Documents\\SEMESTER 3\\CSC 172\\proj2 huffman\\FreqFileTXT.txt";
	static String decodedfile = "C:\\Users\\Nico\\Documents\\SEMESTER 3\\CSC 172\\proj2 huffman\\decodedFileTXT.txt";

	static String inputfileJPG = "ur.jpg";
	static String outputfileJPG = "outputFileJPG.enc";
	static String freqfileJPG = "FreqFileJPG.txt";
	static String decodedfileJPG = "decodedFileJPG.jpg";

	public static void main(String[] args) throws IOException 
	{
		Huffman huffman = new HuffmanSubmit();
		
		huffman.encode(inputfile, outputfile, freqfile);
		huffman.decode(outputfile, decodedfile, freqfile);
	}

	public static void counting(String filee) throws IOException 
	{
		//File inputFile = new File(filee);
		BinaryIn bini = new BinaryIn(filee);


		try 
		{ 

//			BufferedReader br = new BufferedReader(new FileReader(inputFile));

			while(!bini.isEmpty())
			{
				char c = bini.readChar();
				System.out.print(c);
				if(map.containsKey(c))
				{ 
					int temp = map.get(c); 
					temp+=1;
					map.remove(c); 
					map.put(c, temp);
				}
				else 
				{ 
					map.put(c, 1); 
				}
			}
		}

		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	public static Tree_node makeTree()
	{
		PriorityQueue<Tree_node> q = new PriorityQueue<Tree_node>(new Comparator<Tree_node>()
		{	
			public int compare(Tree_node n1, Tree_node n2) 
			{
				if(n1.freq>n2.freq)
				{
					return 1;
				}
				else if(n1.freq<n2.freq)
				{
					return -1;
				}
				else {return 0;}
			}
		});

		//		fill the q with the elements in the map
		for(char element:map.keySet()) 
		{
			q.add(new Tree_node(element, map.get(element)));
		}

		//fillTree(q);

		return fillTree(q);
	}

	public static Tree_node fillTree(PriorityQueue<Tree_node> q) 
	{
		if(q.size()==1) 
		{
			Tree_node huffmanRoot = q.peek();
			return huffmanRoot;

		}
		else 
		{
			Tree_node parent = new Tree_node('\0', 0);
			parent.left = q.poll();
			int temp = 0;
			temp = temp + parent.left.freq;
			parent.right = q.poll();
			//System.out.println(q.peek().freq);
			temp = temp + parent.right.freq;
			parent.freq = temp;
			q.add(parent);

			return fillTree(q);
		}
	}

//		public static void makefrefile(String frqfile) throws IOException
//		{
//			
//			BinaryOut bino = new BinaryOut("C:\\Users\\Nico\\Documents\\SEMESTER 3\\CSC 172\\proj2 huffman\\freqfileusingbin.txt");
//	
//			for(Character start:map.keySet())
//			{
//			char cc = start;
//			int in = (int)cc;
//			
//			binaryRep = Integer.toBinaryString(in); //binary string representation of the char, now  need to make the string binary to save space
//			
//			while(binaryRep.toCharArray().length<8)
//				{
//					binaryRep = "0" + binaryRep;
//				}
//			
//			System.out.println("this is where i want to check: "+binaryRep + map.get(start));
//			f.format("%s%s%s%s", binaryRep, ":", map.get(start) , System.lineSeparator()); // freq file is right
//			bino.write(binaryRep);
//			bino.write(':');
//			bino.write(map.get(start));
//			bino.write('\n');
//			}
//			bino.close();
//		}

	public static void inOrder(String binaryPath, String frqfile, Tree_node start) // traverses the tree, makes freq file and outputfile
	{
		//		BinaryOut bino = new BinaryOut("C:\\Users\\Nico\\Documents\\SEMESTER 3\\CSC 172\\proj2 huffman\\freqfileusingbin.txt");

		if (start.left!=null) 
		{
			inOrder(binaryPath+"1", frqfile, start.left);
		}

		if(start.left == null && start.right == null)
		{
			try
			{
				//final Formatter fd = new Formatter("FreqFile.txt");
				char cc = start.data;
				int in = (int)cc;

				binaryRep = Integer.toBinaryString(in); //binary string representation of the char, now  need to make the string binary to save space

				while(binaryRep.toCharArray().length<8)
				{
					binaryRep = "0" + binaryRep;
				}
				
				if (binaryRep.toCharArray().length>8) return; //maybe wrong

				FileWriter fw = new FileWriter(frqfile, true);
//				fw.write(binaryRep);
//				fw.write(":");
//				fw.write(start.freq);
//				fw.write("\n");
				
				final Formatter f = new Formatter(fw);// make freq file from map

				f.format("%s%s%s%s", binaryRep, ":", start.freq, System.lineSeparator()); // freq file is right
				f.close();
				
//				PrintWriter writter = new PrintWriter(frqfile);
//				writter.print(binaryRep);
//				writter.print(":");
//				writter.print(start.freq);
//				writter.print("\n");
//				writter.println();

//				bino.write(binaryRep);
//				bino.write(":");
//				bino.write(start.freq);
//				bino.write("\n");


				encodeMap.put(start.data, binaryPath);
				//decodeMap.put(binaryPath, start.data);

				System.out.print("|" +start.data + "| "); 
				System.out.print(binaryRep);
				System.out.println(" : " + start.freq);
				
				for(char element : encodeMap.keySet())
				{
					System.out.println(element + " " + encodeMap.get(element));
				}
				
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		}


		if (start.right!=null) 
		{
			inOrder(binaryPath+"0", frqfile, start.right);
		}

		//		bino.close();
	}

	public static void makeOutputFile(String filee, String outpfile) throws IOException
	{

		BinaryOut bino = new BinaryOut(outpfile);
		BinaryIn bini = new BinaryIn(filee);

		try 
		{
			while(!bini.isEmpty())
			{
				char c = bini.readChar();

					if(encodeMap.containsKey(c))
					{ 
						try
						{
							//char[] binaryPath = encodeMap.get(c).toCharArray(); 
							//this gets me each character in the string representation of the binary path
							//for(int l=0; l<binaryPath.length; l++)
							for (char xyz:encodeMap.get(c).toCharArray())
							{
								//char xyz = binaryPath[l];
								if(xyz=='1') {bino.write(true); }
								else if(xyz=='0') {bino.write(false);}
							}
						}
						catch(Exception e) {e.printStackTrace();}
					}
				}
			bino.flush();
			bino.close();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}

	}

	public static Tree_node MakeDecodeTree(String freqfile) throws IOException 
	{	
		File file = new File(freqfile);
		Scanner scanner = new Scanner(file);		

		while(scanner.hasNext())
		{

			String[] split = scanner.nextLine().trim().split(":");
			String s = split[0];

			int bin = Integer.parseInt(s, 2);

			char a = (char)bin;

			int w = Integer.parseInt(split[1]);

			decodeMap.put(a, w);
		}

		PriorityQueue<Tree_node> q = new PriorityQueue<Tree_node>(new Comparator<Tree_node>()
		{	
			public int compare(Tree_node n1, Tree_node n2) 
			{
				if(n1.freq>n2.freq)
				{
					return 1;
				}
				else if(n1.freq<n2.freq)
				{
					return -1;
				}
				else {return 0;}
			}
		});

		for(char element:decodeMap.keySet()) 
		{
			q.add(new Tree_node(element, decodeMap.get(element)));
		}

		//fillTree(q);

		return fillTree(q);

	}


	public static void Decode(String outputFile, String encodedfilename, Tree_node root) throws IOException 
	{

		File outpfile = new File(outputFile);
		BinaryIn bini = new BinaryIn(outputFile);
		BinaryOut bin = new BinaryOut(encodedfilename);

		Tree_node start = root;

		while(!bini.isEmpty())
		{
			boolean b = bini.readBoolean();
			if(!b) //true is 0, 0 is right.
			{
				if(start.right!=null)
					start = start.right;
				if(start.right == null) //means its a leaf
				{					
					//start.data;
					//if (start.data < 0 || start.data >= 256) continue;
					bin.write(start.data);

					start = root; //root.right;
				}

			}
			else // false is 1 1 is left.
			{
				if(start.left!=null)
					start = start.left;
				if(start.left == null)
				{

					//if (start.data < 0 || start.data >= 256) continue;
					bin.write(start.data);

					start = root; //root.left;
				}
			}
		}
		//bin.flush() ;
		bin.close();

	}

	public void encode(String inputFile, String outputFile, String freqFile)
	{

		try
		{
			counting(inputFile);
			inOrder(binaryPath, freqFile, makeTree());		
			makeOutputFile(inputFile, outputFile);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	public void decode(String inputFile, String outputFile, String freqFile)
	{

		try
		{
			Tree_node root = MakeDecodeTree(freqFile);
			Decode(inputFile, outputFile, root);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}