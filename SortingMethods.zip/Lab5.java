/*
 * 
 * nicholas salem 30852013 lab section monday wednesday 2-315pm
 * corbin whitaker 29479887 lab section monday wednesday 4:50pm
 * 
 * 
 * code for the sorting algorithms were found and used from https://www.geeksforgeeks.org/ or lecture
 * 
 */


import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Formatter;
import java.util.Scanner;

public class Lab5<E>
{
	static String filename;
	static File file;

	static ArrayList<Integer> randomArrayL = new ArrayList<Integer>();
	static int[] randomArray;
	static int[] sortedArray;
	static int[] reverseSortedArray;
	static int[] partiallySortedArray;
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) throws Exception 
	{

		filename = args[0]; // "C:\\Users\\Nico\\Documents\\SEMESTER 3\\CSC 172\\lab5\\4Kints.txt";
		file = new File(filename);
//		System.out.println("which sorting alg?");

//		System.out.println("makeRandomArray().length"+makeRandomArray().length);
//		System.out.println("makeSortedArray().length"+makeSortedArray().length);
//		System.out.println("makeReverseSortedArray().length"+makeReverseSortedArray().length);
//		System.out.println("makePartiallySortedArray().length"+makePartiallySortedArray().length);

		makeRandomArray();
		makeSortedArray();
		
		int sortingMethod = Integer.parseInt(args[1]); // scanner.nextInt();

//		if(sortingMethod==1)
//		{
			Stopwatch timer1 = new Stopwatch();
			ArraySortJava(randomArray);
			System.out.println("array's length is : "+randomArray.length);
			timer1.elapsedTime();
			System.out.print("ArraySortJava RandomArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			timer1.elapsedTime();
			System.out.print("ArraySortJava sortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			ArraySortJava(makeReverseSortedArray());
			timer1.elapsedTime();
			System.out.print("ArraySortJava ReverseSortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			ArraySortJava(makePartiallySortedArray());
			timer1.elapsedTime();
			System.out.println("ArraySortJava partiallySortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

//		}
//
//		else if(sortingMethod==2)
//		{
			System.out.println("array's length is : "+randomArray.length);
			timer1 = new Stopwatch();
			BubleSort(randomArray);
			timer1.elapsedTime();
			System.out.print("BubleSort RandomArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			BubleSort(sortedArray);
			timer1.elapsedTime();
			System.out.print("BubleSort sortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			BubleSort(makeReverseSortedArray());
			timer1.elapsedTime();
			System.out.print("BubleSort ReverseSortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			BubleSort(makePartiallySortedArray());
			timer1.elapsedTime();
			System.out.println("BubleSort partiallySortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

//		}
//
//		else if(sortingMethod==3) 
//		{
			System.out.println("array's length is : "+randomArray.length);
			timer1 = new Stopwatch();
			SelectionSort(randomArray);
			timer1.elapsedTime();
			System.out.print("SelectionSort RandomArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			SelectionSort(sortedArray);
			timer1.elapsedTime();
			System.out.print("SelectionSort sortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			SelectionSort(makeReverseSortedArray());
			timer1.elapsedTime();
			System.out.print("SelectionSort ReverseSortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			SelectionSort(makePartiallySortedArray());
			timer1.elapsedTime();
			System.out.println("SelectionSort partiallySortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

//		}
//		else if(sortingMethod==4)
//		{
			System.out.println("array's length is : "+randomArray.length);
			timer1 = new Stopwatch();
			insertionSort(randomArray);
			timer1.elapsedTime();
			System.out.print("insertionSort RandomArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			insertionSort(sortedArray);
			timer1.elapsedTime();
			System.out.print("insertionSort sortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			insertionSort(makeReverseSortedArray());
			timer1.elapsedTime();
			System.out.print("insertionSort ReverseSortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			insertionSort(makePartiallySortedArray());
			timer1.elapsedTime();
			System.out.println("insertionSort partiallySortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

//		}
//
//		else if(sortingMethod==5) 
//		{
			System.out.println("array's length is : "+randomArray.length);
			timer1 = new Stopwatch();
			MergeSort(randomArray);
			timer1.elapsedTime();
			System.out.print("MergeSort RandomArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			MergeSort(sortedArray);
			timer1.elapsedTime();
			System.out.print("MergeSort sortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			MergeSort(makeReverseSortedArray());
			timer1.elapsedTime();
			System.out.print("MergeSort ReverseSortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			MergeSort(makePartiallySortedArray());
			timer1.elapsedTime();
			System.out.println("MergeSort partiallySortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

//		}
//
//		else if(sortingMethod==6) //wrong
//		{
			System.out.println("array's length is : "+randomArray.length);
			timer1 = new Stopwatch();
			QuickSort(randomArray, 0, randomArrayL.size()-1);
			timer1.elapsedTime();
			System.out.print("QuickSort RandomArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			QuickSort(sortedArray, 0, randomArrayL.size()-1);
			timer1.elapsedTime();
			System.out.print("QuickSort sortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			QuickSort(makeReverseSortedArray(), 0, randomArrayL.size()-1);
			timer1.elapsedTime();
			System.out.print("QuickSort ReverseSortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

			timer1 = new Stopwatch();
			QuickSort(makePartiallySortedArray(), 0, randomArrayL.size()-1);
			timer1.elapsedTime();
			System.out.println("QuickSort partiallySortedArray " + timer1.elapsedTime() + " 30852013 " + getName() + "\n");

		//}

		//			printArray(makeRandomArray());
		//			printArray(makeSortedArray());		
		//			printArray(makeReverseSortedArray());
		//			printArray(makePartiallySortedArray());
	}

	public static void makeRandomArray()
	{
		// random number array
		try 
		{
			Scanner scanner = new Scanner(file);

			while(scanner.hasNext())
			{ 
				String split = scanner.next(); //splits by string
				int i = Integer.parseInt(split); //string is converted to int
				randomArrayL.add(i);

			}
			
			randomArray = arrayListToArray(randomArrayL);	
			
		}

		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		//return randomArray;
	}

	public static void makeSortedArray()
	{//reverse sorted array; bigger elements first
		sortedArray = randomArray;
		Arrays.sort(sortedArray);
	}

	public static int[] makeReverseSortedArray()
	{//reverse sorted array; bigger elements first

		reverseSortedArray = randomArray;

		for(int element:reverseSortedArray)
		{
			element = element*-1;
		}

		Arrays.sort(reverseSortedArray);

		for(int element:reverseSortedArray)
		{
			element = element*-1;
		}

		return reverseSortedArray;
	}

	public static int[] makePartiallySortedArray()
	{
		partiallySortedArray = randomArray;
		Number n = partiallySortedArray.length/10;  
		int al = n.intValue();

		Arrays.sort(partiallySortedArray, 0, al);

		return partiallySortedArray;
	}

	public static int[] arrayListToArray(ArrayList<Integer> list)
	{

		int[] array = new int[list.size()];
		int i = 0;
		for(int element:list)
		{
			array[i]=element;
			i++;
		}

		return array;
	}

	public static void printArray(int[] array)
	{
		for(int i =0; i<array.length; i++)
		{
			System.out.println(array[i]);
		}

	}

	public static void ArraySortJava(int[] array)
	{
		Arrays.sort(array);
	}

	public static void BubleSort(int[] array)
	{
		int n = array.length;
		for(int i =0; i<n-1;i++)
		{
			for(int j =0; j<n-i-1;j++)
			{
				if (array[j]>array[j+1])
				{
					int temp = array[j];
					array[j] = array[j+1];
					array[j+1]=temp;
				}
			}
		}
	}

	public static void SelectionSort(int[] arr)
	{


		int n = arr.length; 

		// One by one move boundary of unsorted subarray 
		for (int i = 0; i < n-1; i++) 
		{ 
			// Find the minimum element in unsorted array 
			int min_idx = i; 
			for (int j = i+1; j < n; j++) 
				if (arr[j] < arr[min_idx]) 
					min_idx = j; 

			// Swap the found minimum element with the first 
			// element 
			int temp = arr[min_idx]; 
			arr[min_idx] = arr[i]; 
			arr[i] = temp; 
		} 
	}  




	public static int[] insertionSort(int[] array)
	{
		int n = array.length;
		for(int i=1; i<n; ++i)
		{
			int key = array[i];
			int j = i-1;
			while(j>=0 && array[j]>key)
			{
				array[j+1] = array[j];
				j = j-1;
			}
			array[j+1] = key;
		}
		return array;
	}


	private static int[] merge(int[] a, int[] b) {
		int[] c = new int[a.length + b.length];
		int i = 0, j = 0;
		for (int k = 0; k < c.length; k++) {
			if      (i >= a.length) c[k] = b[j++];
			else if (j >= b.length) c[k] = a[i++];
			else if (a[i] <= b[j])  c[k] = a[i++];
			else                    c[k] = b[j++];
		}
		return c;
	}

	public static int[] MergeSort(int[] input) {
		int N = input.length;
		if (N <= 1) return input;
		int[] a = new int[N/2];
		int[] b = new int[N - N/2];
		for (int i = 0; i < a.length; i++)
			a[i] = input[i];
		for (int i = 0; i < b.length; i++)
			b[i] = input[i + N/2];
		return merge(MergeSort(a), MergeSort(b));
	}

	static <E extends Comparable<? super E>>
    void QuickSort(int[] A, int i, int j) 
	{      // Quicksort
		int pivotindex = findpivot(A, i, j); // Pick a pivot
		swap(A, pivotindex, j);       // Stick pivot at end
		// k will be the first position in the right subarray
		int k = partition(A, i-1, j, A[j]);
		swap(A, k, j);              // Put pivot in place
		if ((k-i) > 1) QuickSort(A, i, k-1);   // Sort left partition
		if ((j-k) > 1) QuickSort(A, k+1, j);   // Sort right partition
	}

	static <E extends Comparable<? super E>>
	int partition(int[] A, int l, int r, int pivot) 
	{
		do {                 // Move bounds inward until they meet
			while (A[++l]<(pivot));
			while ((r!=0) && (A[--r]>(pivot)));
			swap(A, l, r);       // Swap out-of-place values
		} while (l < r);              // Stop when they cross
		swap(A, l, r);         // Reverse last, wasted swap
		return l;      // Return first position in right partition
	}
	
	static <E extends Comparable<? super E>>
	int findpivot(int[] A, int i, int j)
	  { return (i+j)/2; }
	
	public static <E> void swap(int[] A, int p1, int p2) {
	    int temp = A[p1];
		A[p1] = A[p2];
		A[p2] = temp;
	  }
	
	public static String getName()
	{
		String n = "";
		if (filename.equals("C:\\Users\\Nico\\Documents\\SEMESTER 3\\CSC 172\\lab5\\1Kints.txt"))
		{
			n = "1kint.txt";
		}
		else if(filename.equals("C:\\Users\\Nico\\Documents\\SEMESTER 3\\CSC 172\\lab5\\2Kints.txt"))
		{
			n = "2kint.txt";
		}
		else if(filename.equals("C:\\Users\\Nico\\Documents\\SEMESTER 3\\CSC 172\\lab5\\4Kints.txt"))
		{
			n = "4kint.txt";
		}
		else if(filename.equals("C:\\Users\\Nico\\Documents\\SEMESTER 3\\CSC 172\\lab5\\8Kints.txt"))
		{
			n = "8kint.txt";
		}
		else if(filename.equals("C:\\Users\\Nico\\Documents\\SEMESTER 3\\CSC 172\\lab5\\16Kints.txt"))
		{
			n = "16kint.txt";
		}
		else if(filename.equals("C:\\Users\\Nico\\Documents\\SEMESTER 3\\CSC 172\\lab5\\32Kints.txt"))
		{
			n = "32kint.txt";
		}
		else if(filename.equals("C:\\Users\\Nico\\Documents\\SEMESTER 3\\CSC 172\\lab5\\1Mints.txt"))
		{
			n = "1Mint.txt";
		}
		return n;
	}
}