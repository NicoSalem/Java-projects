package newPackage;

public class RNA_LL extends LL
{
	static RNA_LLNODE head;
	static RNA_LLNODE current;

	public static boolean isRNA(LL dna)
	{
		dna.current = dna.head;
		while (dna.current.next!=null)
		{
			if(dna.current.data.equals('g') && !dna.current.data.equals('c') 
			&& !dna.current.data.equals('u') && !dna.current.data.equals('a'))
			{
				return false;
			}
		}
		return true;
	}
}
