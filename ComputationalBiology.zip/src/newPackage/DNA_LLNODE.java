package newPackage;

public class DNA_LLNODE extends LinkedListNode
{
	static char data;
	static DNA_LLNODE next;
}
