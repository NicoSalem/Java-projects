package newPackage;
public class LinkedListNode<T> { 

	T data;
	LinkedListNode next = null;
		
}
