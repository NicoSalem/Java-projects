package newPackage;
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;


public class LAB4_MAIN 
{
	static ArrayList<LL> array = new ArrayList<LL>();
	static DNA_LL dna1 = new DNA_LL();
	static DNA_LL dna2 = new DNA_LL();
	static DNA_LL dna3 = new DNA_LL();
	static DNA_LL dna4 = new DNA_LL();
	static RNA_LL rna1 = new RNA_LL();
	static RNA_LL rna2 = new RNA_LL();
	static RNA_LL rna3 = new RNA_LL();
	static RNA_LL rna4 = new RNA_LL();
	static LL ll = new LL();

	public static void main(String[] args) throws Exception 
	{
		//int arraySize = Integer.parseInt(args[1]);
		String commandFile = args[0];
		LAB4_MAIN biolist = new LAB4_MAIN();
		
		Scanner scan = new Scanner(System.in);
		int arraySize = scan.nextInt();
		array = new ArrayList<LL>(arraySize);
		
		parseFile(biolist, arraySize, commandFile);

		ll.add("is empty");

		insertPosType2(0, dna1, "gggg");
		insertPosType2(0, dna2, "tttt");
		insertPosType2(1, rna1, "uuuu");
		insertPosType2(2, dna3, "agcgaa");
		insertPosType2(3, rna2, "augcugc");
		//		insertPosType2(4, dna4, "atgctgc");
		//		insertPosType2(5, rna4, "augcugc");
		insertPosType2(6, rna3, "augcugc");
		printIndex(0);
		printIndex(1);
		printIndex(2);
		printIndex(3);
		printIndex(4);
		printIndex(5);
		printIndex(6);
		transcribe(2);
		clip2(3,1,4);
		removePos(2);
		print();


	}	

	public static void parseFile(LAB4_MAIN l, int n, String commandFile) throws Exception {
		File file = new File(commandFile);
		Scanner sc = new Scanner(file);
		//method reads the file

		while (sc.hasNextLine()) {
			String [] split = sc.nextLine().trim().split("\\s+");
			if (split[0].equals("print")) {
				print();
			}
			else if (split[0].equals("printIndex")) {
				int var = Integer.parseInt(split[1]);
				printIndex(var);   
			}
			else if (split[0].equals("InsertPostType")) {
				int var = Integer.parseInt(split[1]);
				if(split[2].equals("RNA")) insertPosTypeRNA(var, split[2], split[3]);
				else if(split[2].equals("DNA")) insertPosTypeDNA(var, split[2], split[3]);
			}
			else if (split[0].equals("transcribe")) {
				int var = Integer.parseInt(split[1]);
				transcribe(var); 
			}
			else if (split[0].equals("transcribe")) {
				int var = Integer.parseInt(split[1]);
				transcribe(var); 
			}
			else if (split[0].equals("copypos1topos2")) {
				int var = Integer.parseInt(split[1]);
				int var2 = Integer.parseInt(split[2]);
				copypos1topos2(var, var2); 
			}
			else if (split[0].equals("removePos")) {
				int var = Integer.parseInt(split[1]);
				removePos(var); 
			}
			else if (split[0].equals("")) {
				int var = Integer.parseInt(split[1]);
				removePos(var); 
			}
		}

	}

	public static void insertPosType2(int index, LL type, String seq)
	{
		LL<LinkedListNode> tempLL = type; //makes a temp empty linked list 
		char[] c = seq.toCharArray();

		for(int i=0; i<c.length; i++)
		{
			type.add(c[i]); // iterates trough the sequnce provided and adds to the ll
		}

		try		
		{ 
			if(isDNA(type)&&type.getClass().toString().equals("class newPackage.DNA_LL")) //checks if is an acepptbel dna
			{	
				array.add(index, type); 
				if (array.get(index+1)!=null) {array.remove(array.get(index+1));}
			}
			else if(isRNA(type)&&type.getClass().toString().equals("class newPackage.RNA_LL")) //check if is an acceptable rna
			{
				array.add(index, type);
				if (array.get(index+1)!=null) {array.remove(array.get(index+1));} // if so add
			}
			else {array.add(index, ll); type.print(); System.out.println( " is an invalid sequence");} // if not add an empty linked list
		}
		catch(Exception e )
		{
			//System.out.println(e);
		}
	}

	public static void insertPosTypeRNA(int index, String LLtype, String seq)
	{
		if(!LLtype.equals("RNA")) {return;}
		RNA_LL type = null;
		//makes a temp empty linked list 
		char[] c = seq.toCharArray();

		for(int i=0; i<c.length; i++)
		{
			type.add(c[i]); // iterates trough the sequnce provided and adds to the ll
		}

		try		
		{ 
			if(isDNA(type)&&type.getClass().toString().equals("class newPackage.DNA_LL")) //checks if is an acepptbel dna
			{	
				array.add(index, type); 
				if (array.get(index+1)!=null) {array.remove(array.get(index+1));}
			}
			else if(isRNA(type)&&type.getClass().toString().equals("class newPackage.RNA_LL")) //check if is an acceptable rna
			{
				array.add(index, type);
				if (array.get(index+1)!=null) {array.remove(array.get(index+1));} // if so add
			}
			else {array.add(index, ll); type.print(); System.out.println( " is an invalid sequence");} // if not add an empty linked list
		}
		catch(Exception e )
		{
			//System.out.println(e);
		}
	}

	public static void insertPosTypeDNA(int index, String LLtype, String seq)
	{
		if(!LLtype.equals("DNA")) {return;}
		RNA_LL type = null;
		//makes a temp empty linked list 
		char[] c = seq.toCharArray();

		for(int i=0; i<c.length; i++)
		{
			type.add(c[i]); // iterates trough the sequnce provided and adds to the ll
		}

		try		
		{ 
			if(isDNA(type)&&type.getClass().toString().equals("class newPackage.DNA_LL")) //checks if is an acepptbel dna
			{	
				array.add(index, type); 
				if (array.get(index+1)!=null) {array.remove(array.get(index+1));}
			}
			else if(isRNA(type)&&type.getClass().toString().equals("class newPackage.RNA_LL")) //check if is an acceptable rna
			{
				array.add(index, type);
				if (array.get(index+1)!=null) {array.remove(array.get(index+1));} // if so add
			}
			else {array.add(index, ll); type.print(); System.out.println( " is an invalid sequence");} // if not add an empty linked list
		}
		catch(Exception e )
		{
			//System.out.println(e);
		}
	}

	public static void printIndex(int index)
	{
		try
		{
			if (array.get(index).getClass().toString().equals("class newPackage.DNA_LL"))  // just prints the class and sequnce of the index
			{
				System.out.print("position: " + index + " DNA: ");
				array.get(index).print();
				System.out.println();
			}
			else if(array.get(index).getClass().toString().equals("class newPackage.RNA_LL")) 
			{
				System.out.print("position: " + index + " RNA: ");
				array.get(index).print();
				System.out.println();
			}
			else if (array.get(index).head.data.equals("is empty")) System.out.println("position: " + index + " is empty");
		}
		catch(Exception e) 
		{
			System.out.println("position: " + index + " is empty!");
		}

	}

	public static void print() // print the entire array
	{
		int i=0;

		while(i<array.size())
		{
			try
			{
				if (array.get(i).getClass().toString().equals("class newPackage.DNA_LL")) System.out.print("position: " + i + " DNA: ");
				else if (array.get(i).getClass().toString().equals("class newPackage.RNA_LL")) System.out.print("position: " + i + " RNA: ");
				else if (array.get(i).head.data.equals("is empty")) { System.out.print("position: " + i +" ");}
				array.get(i).print();
				System.out.println();
				i++;
			}

			catch(Exception e)
			{
				System.out.println("position: " + i + " is emptyy");
				i++;
			}
		}
	}

	public static void removePos(int pos) // removes the liked list inside the array at the position determined 
	{
		try
		{
			if(array.get(pos)!=null) 
			{
				array.set(pos, null);
				System.out.println("position: " +pos+ " was deleted");
			}
			else  System.out.println("this postion is already empty");
		}
		catch(Exception e)
		{
			System.out.println("posiotion: " +pos+ "is already empty");
		}
	}

	public static void copypos1topos2(int pos1, int pos2) // makes the sequence at pos 2 that of pos 1
	{
		try 
		{
			array.get(pos1);
		}
		catch(NullPointerException e) 
		{
			System.out.println("position" +pos2+ "is empty");
		}
		array.set(pos2, array.get(pos1));
	}

	public static boolean isDNA(LL dna) // checks if the ll only contains letters of dna
	{
		dna.current = dna.head;
		while (dna.current.next!=null)
		{
			if(!dna.current.data.equals('g') && !dna.current.data.equals('c') && !dna.current.data.equals('t') && !dna.current.data.equals('a'))
			{
				return false;
			}
			dna.current = dna.current.next;
		}
		return true;
	}
	public static boolean isRNA(LL dna)// checks if the ll only contains letters of rna
	{
		dna.current = dna.head;
		while (dna.current.next!=null)
		{
			if(!dna.current.data.equals('g') && !dna.current.data.equals('c') && !dna.current.data.equals('u') && !dna.current.data.equals('a'))
			{
				return false;
			}
			dna.current = dna.current.next;
		}
		return true;
	}

	public static void transcribe(int pos) // transcribes the dna into a rna by deleting the ll and adding a new one with the corresponding rna letters
	{
		try
		{
			if (array.get(pos).getClass().toString().equals("class newPackage.RNA_LL")) {System.out.println(" sequence is an RNA");return;}

			array.get(pos).current = array.get(pos).head;
			RNA_LL rnat = new RNA_LL();
			while(array.get(pos).current!=null)
			{
				if(array.get(pos).current.data.equals('g')) {rnat.add('c');}
				if(array.get(pos).current.data.equals('c')) {rnat.add('g');}
				if(array.get(pos).current.data.equals('a')) {rnat.add('t');}
				if(array.get(pos).current.data.equals('t')) {rnat.add('u');}
				array.get(pos).current = array.get(pos).current.next;
			}
			array.add(pos, rnat);
			array.remove(4);
		}
		catch(Exception e)
		{
			System.out.println("position: " +pos+ "is empty!!");
		}
	}

	public static void clip2 (int pos, int start, int end) // changes the LL to only the elements starting at start  and ending at end
	{
		int count = 0;
		LL<LinkedListNode> currLL = array.get(pos);

		LinkedListNode head = currLL.head;
		while (count!=start) {
			head = head.next;
			count++;
		}
		LinkedListNode newHead = head;

		while (count!=end) {
			head = head.next;
			count++;
		}
		head.next = null;
		currLL.head = newHead;

	}
}
