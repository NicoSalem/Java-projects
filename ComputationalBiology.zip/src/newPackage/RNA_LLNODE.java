package newPackage;

public class RNA_LLNODE extends LinkedListNode
{
	static char data;
	static RNA_LLNODE next;
	
	
}
