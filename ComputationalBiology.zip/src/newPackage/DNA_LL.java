package newPackage;

public class DNA_LL extends LL
{
  	static DNA_LLNODE head;
	static DNA_LLNODE current;

	public static boolean isDNA(LL dna)
	{
		dna.current = dna.head;
		while (dna.current.next!=null)
		{
			if(!dna.current.data.equals('g') && !dna.current.data.equals('c') 
			&& !dna.current.data.equals('t') && !dna.current.data.equals('a'))
			{
				return false;
			}
		}
		return true;
	}
}
