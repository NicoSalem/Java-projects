package newPackage;

public class Sequences 
{
	static DNA_LL dna1 = new DNA_LL();
	static DNA_LL dna2 = new DNA_LL();
	static RNA_LL rna1 = new RNA_LL();
	static RNA_LL rna2 = new RNA_LL();
	
	public static void main(String[] args)
	{
		
		dna1.add("t");
		dna1.add("t");
		dna1.add("t");
		dna1.add("t");
		
		
		dna1.add("a");
		dna1.add("a");
		dna1.add("a");
		dna1.add("a");
		
		
		rna2.add("c");
		rna2.add("c");
		rna2.add("c");
		rna2.add("c");
		
		
		rna2.add("g");
		rna2.add("g");
		rna2.add("g");
		rna2.add("g");
		
	}
	
}
