import java.util.LinkedList;

public class Node 
{

	String name;
	Double lat;
	Double lon;
	Double distance;
	LinkedList<Node> neighbors = new LinkedList<Node>();


	public Node(String name, Double lat, Double lon, Double distance)
	{
		this.name = name;
		this.lat = lat;
		this.lon = lon;
		this.distance = distance;
	}
	
	public void setDistance(Double d)
	{
		distance = d;
	}
	
}
