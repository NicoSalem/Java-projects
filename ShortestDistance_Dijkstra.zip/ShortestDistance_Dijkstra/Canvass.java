// NICHOLAS SALEM AND CORBIN WHITAKER

import javax.swing.*;

public class Canvass
{
    static JFrame f = new JFrame();
    static int w ;
    static int h ; //f.getHeight();

    public static void main(String[] args)
    {
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Main m = new Main();
        f.add(m);
        f.setSize(w,h);
        f.setVisible(true);
    }

    public static int getWidth()
    {
        w = f.getWidth();
        return w;
    }

    public static int getHeight()
    {
        h = f.getHeight();
        return h;
    }
}
