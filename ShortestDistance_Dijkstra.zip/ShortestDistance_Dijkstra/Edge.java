
public class Edge 
{

	String road;
	String start;
	String end;
	Double length;
	
	public Edge(String road, String start, String end)
	{
		this.road = road;
		this.start = start;
		this.end = end;
	}
	
}
