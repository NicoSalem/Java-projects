// NICHOLAS SALEM AND CORBIN WHITAKER

import javax.swing.*;
import java.awt.*;
import java.awt.Event;
import java.awt.Graphics;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.ArrayList;


public class Main extends JPanel {
    static Node begin;
    static Node dest;

    static Double i = Double.POSITIVE_INFINITY;
    static Double minlat = i;
    static Double minlon = i;
    static Double maxlat = -i;
    static Double maxlon = -i;
    static Canvass canvas = new Canvass();

    static HashMap<String, Node> map = new HashMap<String, Node>();
    static HashMap<Node, Boolean> visited = new HashMap<Node, Boolean>();
    static HashMap<Node, Double> vdistance = new HashMap<Node, Double>();
    static HashMap<Node, Node> path = new HashMap<Node, Node>();
    static HashMap<String, Edge> edges = new HashMap<>();
    static ArrayList<Node> graphicspath = new ArrayList<>();

    static String filename;

    static PriorityQueue<Node> q = new PriorityQueue<Node>(new Comparator<Node>() {
        public int compare(Node n1, Node n2) {
            if (n1.distance > n2.distance) {
                return 1;
            } else if (n1.distance < n2.distance) {
                return -1;
            } else {
                return 0;
            }
        }
    });


    public static void main(String[] args) throws FileNotFoundException
    {
        if(args[0].equals("ur.txt"))
        {
            filename ="ur.txt";
        }
        else if(args[0].equals("monroe.txt"))
        {
            filename ="monroe.txt";
        }
        else if(args[0].equals("nys.txt"))
        {
            filename ="nys.txt";
        }

        if(args.length==5)
        {
            if(args[1].equals("--show") && args[2].equals("--directions"))
            {
                String a = args[3];
                String b = args[4];

                try {
                    readFile(filename);
                    findmin();
                    dijkstra(a, b);
                    canvas.main(args);

                    for (Node element : graphicspath) {
                        System.out.println(element.name);
                    }
                }
                catch(NullPointerException e)
                {
                    System.out.println("nodes are not connected");
                }
            }
        }
        else if(args[1].equals("--show"))
        {
            try {
                readFile(filename);
                findmin();
                canvas.main(args);
            }
            catch(NullPointerException e)
            {
                System.out.println("nodes are not connected");
            }
        }
        else if(args[1].equals("--directions")){
            String a = args[2];
            String b = args[3];
            try {
                readFile(filename);
                findmin();
                dijkstra(a,b);
                for (Node element : graphicspath) {
                    System.out.println(element.name);
                }
            }
            catch(NullPointerException e)
            {
                System.out.println("nodes are not connected");
            }
        }
    }

    public static void readFile(String f) throws FileNotFoundException {
        File file = new File(f);
        Scanner scanner = new Scanner(file);

        while (scanner.hasNext()) {
            String split = scanner.next();
            Node n;
            Edge e;

            if (split.equals("i")) {
                String a = scanner.next();
                n = new Node(a, scanner.nextDouble(), scanner.nextDouble(), Double.POSITIVE_INFINITY);
                //	System.out.println("name: " + n.name + " lat: " + n.lat + " lon: " + n.lon);
                map.put(a, n);
                //	q.add(map.get(a));
                vdistance.put(n, Double.POSITIVE_INFINITY);
                visited.put(n, false);
            }

            else if (split.equals("r")) {
                String ee = scanner.next();
                e = new Edge(ee, scanner.next(), scanner.next());
                e.length = findLength(e);
                //	System.out.println("road: "+e.road+" start: "+e.start+" end: "+e.end+" length: "+e.length);
                //	System.out.println("added: " + map.get(e.end).name + " to: " + map.get(e.start).name);
                map.get(e.start).neighbors.add(map.get(e.end));
                map.get(e.end).neighbors.add(map.get(e.start));
                edges.put(ee, e);
            }
        }
    }

    public static void dijkstra(String startt, String endd) {
        Node start = map.get(startt);
        Node end = map.get(endd);

        begin = start;
        dest = end;

        start.setDistance(0.0);
        q.add(start);
        path.put(start, start);

        Node nodemin;

        int i =0;
        while (visited.containsValue(false)) {
            nodemin = q.poll();

            if (nodemin == null)
            {
                i++;
                //System.out.println("we got a null " + i);
                break;
            }
            else {
                //System.out.println("dijkstra");

                if (!visited.get(nodemin)) // if false = if not visited ...
                {
                    for (Node elem : nodemin.neighbors) {
                        if (!visited.get(elem)) // if false = if not visited ...
                        {
                            double d1 = findLength(nodemin, elem);
                            double d2 = nodemin.distance;
                            double d = d1 + d2;

                            if (d < elem.distance) {
                                elem.setDistance(d);
                                path.remove(elem);
                                path.put(elem, nodemin);
                                q.add(elem);
                            }
                            else{continue;}
                        }
                    }
                }
            }
            visited.remove(nodemin);
            visited.put(nodemin, true);
        }

        System.out.println("shortest distance : " + map.get(endd).distance);
        printSP(start, end);
    }


    public static void print() {
        for (String element : map.keySet()) {
            System.out.println("node: " + map.get(element).name);
            System.out.print("neighbors: ");

            for (Node ele : map.get(element).neighbors) {
                System.out.print(ele.name + ", ");
            }
            System.out.println();
        }
    }

    public static void printPathMap() {
        for (Node element : path.keySet()) {
            System.out.print(element.name + " -> ");
            System.out.println(path.get(element).name);
        }
    }

    public static void printQ() {
        while (q.iterator().hasNext()) {
            System.out.println("node: " + q.peek().name + " " + q.poll().distance);
        }
    }

    public static void printSP(Node start, Node end) {
        System.out.println("shortest path:");
        Node current;
        current = end;
        //System.out.println(beginsat.name);
        graphicspath.add(current);
        do {
            graphicspath.add(path.get(current));
            //  System.out.println(path.get(beginsat).name); // returns the prev node
            current = path.get(current);
        }
        while (!current.name.equals(start.name));
    }

    public static void findmin() {
        for (String element : map.keySet()) {
            if (map.get(element).lat < minlat) {
                minlat = map.get(element).lat;
            }
            if (map.get(element).lat > maxlat) {
                maxlat = map.get(element).lat;
            }
            if (map.get(element).lon < minlon) {
                minlon = map.get(element).lon;
            }
            if (map.get(element).lon > maxlon) {
                maxlon = map.get(element).lon;
            }
        }

//		System.out.println("minlat: " + minlat);
//		System.out.println("minlon: " + minlon);
//		System.out.println("maxlat: " + maxlat);
//		System.out.println("maxlon: " + maxlon);

    }

    public static Double findLength(Edge e) {
        Double startlat = map.get(e.start).lat;
        Double endlat = map.get(e.end).lat;

        Double startlon = map.get(e.start).lat;
        Double endlon = map.get(e.end).lon;

        double dlat = Math.toRadians(endlat - startlat);
        double dlon = Math.toRadians(endlon - startlon);

        double a = Math.pow(Math.sin(dlat / 2), 2) + Math.cos(startlat) * Math.cos(endlat) *
                Math.pow(Math.sin(dlon / 2), 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        Double length = 3959 * c;

        return length;
    }

    public static double findLength(Node start, Node end)
    {
        double dlat = Math.toRadians(end.lat-start.lat);
        double dlon = Math.toRadians(end.lon-start.lon);

        double lat1 = Math.toRadians(start.lat);
        double lat2 = Math.toRadians(end.lat);

        double a = Math.pow(Math.sin(dlat/2),2) + Math.pow(Math.sin(dlon/2),2) *
                Math.cos(lat1) * Math.cos(lat2);

        double c = 2 * Math.asin(Math.sqrt(a));

        double length = 3959 * c;

        return length;
    }

    public static double convertLat(Double in) {
        double range = (maxlat - minlat);
        double out = ((canvas.getHeight()-100) * (in - (minlat)) / (range)+50);

        return out;
    }

    public static double convertLon(Double in) {
        double range = (maxlon - minlon);
        double out = ((canvas.getWidth()-100) * (in - (minlon)) / (range)+50);

        return out;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        this.setBackground(Color.black);
        g.setColor(Color.green);

//        for (String element : map.keySet()) {
//            double x = convertLat(map.get(element).lat);
//            double y = convertLon(map.get(element).lon);
//
//            //System.out.println("convert method: " + x + " " + y);
//           // g.fillOval( (int)y, canvas.getHeight()-(int) x, 1, 1);
//        }

        for (String element : edges.keySet()) {
            String s = edges.get(element).start;
            Node start = map.get(edges.get(element).start);
            double d = convertLat(map.get(edges.get(element).start).lat);

            if(graphicspath.contains(map.get(edges.get(element).start)) && graphicspath.contains(map.get(edges.get(element).end)))
            {
                //System.out.println("yes");
                g.setColor(Color.magenta);
               // g.fillOval( (int) convertLon(map.get(edges.get(element).start).lon), canvas.getHeight()-(int) convertLat(map.get(edges.get(element).start).lat), 4, 4);
                g.drawLine((int) convertLon(map.get(edges.get(element).start).lon), canvas.getHeight()-(int) convertLat(map.get(edges.get(element).start).lat),
                        (int) convertLon(map.get(edges.get(element).end).lon), canvas.getHeight()-(int) convertLat(map.get(edges.get(element).end).lat));
            }
            else {
                g.setColor(Color.green);
                //System.out.println("no");
                g.drawLine((int) convertLon(map.get(edges.get(element).start).lon), canvas.getHeight()-(int) convertLat(map.get(edges.get(element).start).lat),
                        (int) convertLon(map.get(edges.get(element).end).lon), canvas.getHeight()-(int) convertLat(map.get(edges.get(element).end).lat));
            }
        }

        if(filename.equals("nys.txt")){
            g.setFont(new Font("copperplate", Font.ITALIC, 20));
            g.drawString("MAP OF NEW YORK STATE" , canvas.getWidth()/10,(int)canvas.getHeight()/20);
        }
        else if(filename.equals("monroe.txt")){
            g.setFont(new Font("copperplate", Font.ITALIC, 20));
            g.drawString("MAP OF MONROE COUNTY" , canvas.getWidth()-canvas.getWidth()/2,(int)canvas.getHeight()/10);
        }
        else if(filename.equals("ur.txt")){
            g.setFont(new Font("copperplate", Font.ITALIC, 20));
            g.drawString("MAP OF RIVER CAMPUS",canvas.getWidth()/10,(int)canvas.getHeight()/10);
        }
    }
}
